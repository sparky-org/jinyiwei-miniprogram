/**
 * 请求数据的url
 */
exports = {
  //首页数据
  indexData: '/home/index'
}
