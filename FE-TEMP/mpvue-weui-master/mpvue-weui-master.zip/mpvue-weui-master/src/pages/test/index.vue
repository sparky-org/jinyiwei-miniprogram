<template>
  <div class="page">
  </div>
</template>

<script>
export default {
  data() {
    return {
    }
  },
  computed: {

  },
  methods: {

  }
}
</script>

<style scoped>

</style>
