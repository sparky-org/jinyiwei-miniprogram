<template>
  <div class="page">
    <view class="page__hd">
      <view class="page__title">Tabbar</view>
      <view class="page__desc">底部导航，建议采用小程序原生的tabbar，通过设置page/main.js（即对应小程序中app.json）来实现。详情请看小程序文档。</view>
    </view>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
