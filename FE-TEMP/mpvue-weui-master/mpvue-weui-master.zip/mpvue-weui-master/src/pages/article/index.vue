<template>
  <div class="page">
    <div class="page__hd">
        <div class="page__title">Article</div>
        <div class="page__desc">文章</div>
    </div>
    <div class="page__bd">
        <div class="weui-article">
            <div class="weui-article__h1">大标题</div>
            <div class="weui-article__section">
                <div class="weui-article__title">章标题</div>
                <div class="weui-article__section">
                    <div class="weui-article__h3">1.1 节标题</div>
                    <div class="weui-article__p">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                        consequat.
                    </div>
                    <div class="weui-article__p">
                        <image class="weui-article__img" src="/static/images/pic_article.png" mode="aspectFit" style="height: 180px" />
                        <image class="weui-article__img" src="/static/images/pic_article.png" mode="aspectFit" style="height: 180px" />
                    </div>
                </div>
                <div class="weui-article__section">
                    <div class="weui-article__h3">1.2 节标题</div>
                    <div class="weui-article__p">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                        proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>

<script>
export default {

}
</script>

<style>

</style>
