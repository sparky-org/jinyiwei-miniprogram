export const mpvueInfo = state => state.mpvueInfo;
